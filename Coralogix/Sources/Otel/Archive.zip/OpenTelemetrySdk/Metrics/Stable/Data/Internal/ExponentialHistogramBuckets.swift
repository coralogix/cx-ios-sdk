//
// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
//

import Foundation
// 

public protocol ExponentialHistogramBuckets {
    var scale : Int { get }
    var offset : Int { get }
    var bucketCounts : [Int64] { get }
    var totalCount : Int { get }
}
