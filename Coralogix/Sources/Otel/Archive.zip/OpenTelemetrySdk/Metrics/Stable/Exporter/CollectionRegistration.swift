//
// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
// 

import Foundation


// Stubbed protocol for support of custom MetricReaders in the future
public protocol CollectionRegistration {}
