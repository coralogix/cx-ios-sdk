//
// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
// 

import Foundation

public class StableObservableMeasurementSdk : ObservableLongMeasurement, ObservableDoubleMeasurement {
    private var instrumentScope : InstrumentationScopeInfo
    public private(set) var descriptor : InstrumentDescriptor
    public private(set) var storages : [AsynchronousMetricStorage]
    private var activeReader : RegisteredReader?
    
    var startEpochNanos : UInt64 = 0
    var epochNanos : UInt64 = 0
    
    init(insturmentScope: InstrumentationScopeInfo, descriptor: InstrumentDescriptor, storages: [AsynchronousMetricStorage]) {
        self.instrumentScope = insturmentScope
        self.descriptor = descriptor
        self.storages = storages
    }
    
    func setActiveReader(reader: RegisteredReader, startEpochNanos : UInt64, epochNanos : UInt64) {
        activeReader = reader
        self.startEpochNanos = startEpochNanos
        self.epochNanos = epochNanos
    }
    
    public func clearActiveReader() {
        activeReader = nil
    }
    public func record(value: Int) {
        record(value: value, attributes: [String:AttributeValue]())
    }
    
    public func record(value: Int, attributes: [String : AttributeValue]) {
        record(value: Double(value), attributes: attributes)
    }
    
    public func record(value: Double) {
        record(value: value, attributes: [String: AttributeValue]())
    }
    
    public func record(value: Double, attributes: [String : AttributeValue]) {
        doRecord(measurement: Measurement.doubleMeasurement(startEpochNano: startEpochNanos, endEpochNano: epochNanos, value: value, attributes: attributes))
    }
    
    private func doRecord(measurement : Measurement) {
        guard let _ = activeReader else {
            //todo: error log
            return
        }
        storages.forEach { storage in
            if storage.registeredReader == activeReader {
                storage.record(measurement: measurement)
            }
            
        }
    }
}
