//
// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0
// 

import Foundation

extension Resource {
    public static let OTEL_SWIFT_SDK_VERSION : String = "1.9.2"
}
